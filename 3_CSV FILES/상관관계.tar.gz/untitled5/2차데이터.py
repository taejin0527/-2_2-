import csv
from datetime import datetime, timedelta

station = list()

f1 = open('data1.csv', 'r', encoding='utf-8')
rdr1 = csv.reader(f1)

for line in rdr1:
    if line[1] == 'LEFT' and line[3] == '1':
        station.append(line[7]) #버스가 첫번째 정류장 enter 한 시간
    if line[1] == 'LEFT' and line[3] == '2':
        station.append(line[7])  #버스가 left_last 한 시간

line_counter = 0
header = []
bus = []

j = 0
with open('7월(y값같이).csv') as f2:
    while 1:
        data = f2.readline().replace("\n", "")
        #print(data)
        if not data:
            break
        if line_counter == 0:
            header = data.split(",")
        else:
            if station[j][0:10] == data.split(",")[0][0:10]:
                print("here")
                print(data.split(",")[0])
            else:
                j = j + 2
            time1 = datetime(int(station[j][0:4]), int(station[j][5:7]), int(station[j][8:10]), int(station[j][11:13]),
                             int(station[j][14:16]), int(station[j][17:19]))
            time2 = datetime(int(data.split(",")[0][0:4]), int(data.split(",")[0][5:7]), int(data.split(",")[0][8:10]),
                             int(data.split(",")[0][11:13]), int(data.split(",")[0][14:16]),
                             int(data.split(",")[0][17:19]))
            time3 = datetime(int(station[j+1][0:4]), int(station[j+1][5:7]), int(station[j+1][8:10]),
                             int(station[j+1][11:13]), int(station[j+1][14:16]), int(station[j+1][17:19]))
            #print(time1, time2, time3)
            if time1 <= time2 <= time3:
                bus.append(data.split(","))
        line_counter = line_counter + 1

print(station)
print(bus)
with open('7월.csv', 'w') as f3:
    f3.write(",".join(header)+'\n')
    for i in bus:
        f3.write(",".join(i)+'\n')
#print(header)
