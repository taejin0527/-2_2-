import csv
from datetime import datetime, timedelta

station = list()
day = list()
bus = list()
time = list()

name = []
f1 = open('data1.csv', 'r', encoding='utf-8')
f2 = open('data2(12월).csv', 'r', encoding='utf-8')
f4 = open('out(12월).txt', 'w')

rdr1 = csv.reader(f1)
rdr2 = csv.reader(f2)

for line in rdr1:
    if line[1] == 'LEFT' and line[3] == '2':
        station.append(line[7])

print(station)

name = ['data2(1월)', 'data2(2월)', 'data2(3월)', 'data2(4월)', 'data2(5월)', 'data2(6월)', 'data2(7월)', 'data2(8월)',
        'data2(9월)', 'data2(10월)', 'data2(11월)', 'data2(12월)']

for line in rdr2:
    bus.append(line[0])

for i in range(len(station)):
    for j in range(len(bus)):
        if station[i][0:10] == bus[j][0:10]:
            time1 = datetime(int(station[i][0:4]), int(station[i][5:7]), int(station[i][8:10]), int(station[i][11:13]),
                             int(station[i][14:16]), int(station[i][17:19]))
            time2 = datetime(int(bus[j][0:4]), int(bus[j][5:7]), int(bus[j][8:10]), int(bus[j][11:13]),
                             int(bus[j][14:16]), int(bus[j][17:19]))
            print(time1)
            print(time2)
            date = time1-time2
            day.append(str(date))


print(len(day))
for i in range(len(day)):
    #print(day[i])
    #wr.writerow(day[i])
    f4.write(day[i])
    f4.write('\n')

f1.close()
f2.close()
#f3.close()
f4.close()
